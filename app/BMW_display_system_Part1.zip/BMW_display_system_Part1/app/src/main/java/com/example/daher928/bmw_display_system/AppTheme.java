package com.example.daher928.bmw_display_system;

enum ThemeColor {
    BLUE, RED
}
public class AppTheme {

    public static ThemeColor theme = ThemeColor.BLUE;

    public static void changeTheme(ThemeColor new_theme){
        theme = new_theme;
    }
}
